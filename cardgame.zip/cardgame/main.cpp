#include <QApplication>
#include "cardgame.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    CardGame game;
    game.show();
    return a.exec();
}
