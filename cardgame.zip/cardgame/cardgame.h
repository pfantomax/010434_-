#ifndef CARDGAME_H
#define CARDGAME_H

#include <QMainWindow>
#include <QVector>

class QLabel;
class QPushButton;
class QListWidget;

struct Card {
    int value;
    QString suit;
};

class CardGame : public QMainWindow {
    Q_OBJECT

public:
    CardGame(QWidget *parent = nullptr);

private slots:
    void drawCard();
    void resetGame();

private:
    void setupUI();
    void setupDeck();
    void updateScore();
    void displayCard(const Card &card);
    void updateHandList();

    QVector<Card> deck;
    QVector<Card> player1Hand;
    QVector<Card> player2Hand;
    int player1Points;
    int player2Points;
    QLabel *scoreLabel;
    QLabel *cardLabel;
    QListWidget *player1ListWidget;
    QListWidget *player2ListWidget;
    int currentPlayer;
    QPushButton *drawButton;
};

#endif // CARDGAME_H
