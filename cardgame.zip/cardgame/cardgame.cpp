#include "cardgame.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QListWidget>
#include <QRandomGenerator>
#include <QMessageBox>

CardGame::CardGame(QWidget *parent)
    : QMainWindow(parent), player1Points(0), player2Points(0), currentPlayer(1) {
    setupUI();
    setupDeck();
}

void CardGame::drawCard() {
    QVector<Card> &currentPlayerHand = (currentPlayer == 1) ? player1Hand : player2Hand;

    if (!deck.isEmpty()) {
        Card drawnCard = deck.takeLast();
        currentPlayerHand.append(drawnCard);
        int &currentPlayerPoints = (currentPlayer == 1) ? player1Points : player2Points;
        currentPlayerPoints += drawnCard.value;

        updateScore();
        displayCard(drawnCard);
        updateHandList();

        if (currentPlayerPoints > 24) {
            QString winner = (currentPlayer == 1) ? "Гравець 2" : "Гравець 1";
            QMessageBox::information(this, "Гра завершена", winner + " переміг!");
            resetGame();
        } else {
            currentPlayer = (currentPlayer == 1) ? 2 : 1;
        }
    }
}

void CardGame::resetGame() {
    deck.clear();
    player1Hand.clear();
    player2Hand.clear();
    player1Points = 0;
    player2Points = 0;
    currentPlayer = 1;
    updateScore();
    displayCard({0, ""});
    updateHandList();
}

void CardGame::setupUI() {
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);

    scoreLabel = new QLabel("Очки Гравець 1: 0, Гравець 2: 0", this);
    mainLayout->addWidget(scoreLabel);

    cardLabel = new QLabel("Карта: ", this);
    mainLayout->addWidget(cardLabel);

    player1ListWidget = new QListWidget(this);
    mainLayout->addWidget(player1ListWidget);

    player2ListWidget = new QListWidget(this);
    mainLayout->addWidget(player2ListWidget);

    drawButton = new QPushButton("Тягнути карту", this);
    connect(drawButton, &QPushButton::clicked, this, &CardGame::drawCard);
    mainLayout->addWidget(drawButton);

    setWindowTitle("Карткова Гра");
}

void CardGame::setupDeck() {
    const QStringList suits = {"Черви", "Бубни", "Піки", "Трефи"};

    for (const QString &suit : suits) {
        for (int value = 1; value <= 10; ++value) {
            Card card;
            card.value = value;
            card.suit = suit;
            deck.append(card);
        }
    }

    std::random_shuffle(deck.begin(), deck.end());
}

void CardGame::updateScore() {
    scoreLabel->setText(QString("Очки Гравець 1: %1, Гравець 2: %2").arg(player1Points).arg(player2Points));
}

void CardGame::displayCard(const Card &card) {
    QString cardText = (card.value > 0) ? QString("Карта: %1 %2").arg(card.value).arg(card.suit) : "Карта: ";
    cardLabel->setText(cardText);
}

void CardGame::updateHandList() {
    QListWidget *currentPlayerListWidget = (currentPlayer == 1) ? player1ListWidget : player2ListWidget;
    const QVector<Card> &currentPlayerHand = (currentPlayer == 1) ? player1Hand : player2Hand;

    currentPlayerListWidget->clear();
    for (const Card &card : currentPlayerHand) {
        QString cardText = QString("%1 %2").arg(card.value).arg(card.suit);
        currentPlayerListWidget->addItem(cardText);
    }
}
